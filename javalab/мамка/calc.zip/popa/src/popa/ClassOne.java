package popa;

public class ClassOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 18;
		System.out.print("Hello, Mamka!");
		System.out.println("99!");
		
		System.out.println("Mamka!" + age);
		
	}

}
